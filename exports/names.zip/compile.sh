#!/bin/bash

zip -r names.zip compile.sh favicon.png favicon.png.import index.html index.js index.pck index.png index.png.import index.wasm
